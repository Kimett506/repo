import xbmc
from resources.lib.modules._addon import *
from resources.lib.modules._common import *



class Service(object):

	started     = False
	completed   = False

	def __init__(self):
		self.loadtype = int(setting('getepgdata'))
		self.Services = ['gold','red','green']
		self.Epgs     = ['EpgUk','EpgUs','EpgEs','EpgDe','EpgMy','EpgHk']
		self.MyServices = self.MyServices()
		self.MyEpgList  = self.MyEpgList()


	def XMLTvConstruct(self):
		if len(self.MyServices) >= 1 and self.loadtype == 0:
			if setting_true('clear_all_epg_data'):
				if PathExists(epg_folder):
					DelAllContents(epg_folder)
				setting_set('clear_all_epg_data','false')
			CreateDir(epg_folder)
			self.started = True
			from resources.lib.modules import epg_source
			for Service in self.MyServices:
				epg_source.GetServiceXmlTv(Service)
			for Epg, Service in [(Epg,Service) for Epg in self.MyEpgList for Service in self.MyServices]:
				country = Epg.lower().replace('epg','').strip()
				CreateDir(eval('{}_epg_folder'.format(country.lower())))
				epg_source.CustomXMLTV(service_name=Service,epg_country=country)
				Notify(message='{} EPG Modified for {} Service'.format(country.upper(),Service.capitalize()))
			else:
				self.completed = True
		else:
			self.CloseService()

	def CloseService(self):
		import sys
		sys.exit()

	def DelEpgFiles(self):
		DelAllContents(epg_folder)

	def MyServices(self):
		a = []
		for Service in self.Services:
			if setting_true('{}enabled'.format(Service)):
				if Service not in a:
					a.append(Service)
		return a 

	def MyEpgList(self):
		i = list()
		for Epg in self.Epgs:
			if setting_true('{}'.format(Epg)):
				i.append(Epg)
		return i 



if __name__ == '__main__':
	Service = Service()
	Service.XMLTvConstruct()
	monitor = xbmc.Monitor()
	while  not Service.completed:
		if monitor.abortRequested():
			Service.DelEpgFiles()
			Service.CloseService()
