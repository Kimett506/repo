# -*- coding: utf-8 -*-
import datetime
import dateutil.parser as dparser
import difflib
import inspect 
import re
import requests
import time
import urllib
import xbmc
import xbmcgui
import xbmcplugin 
import xbmcvfs
from bs4 import BeautifulSoup
from resources.lib.modules import panelcalls
from resources.lib.modules._addon import *
from resources.lib.modules._common import *

Services = ['gold','red','green']
Settings = ['username','password']
Epgs     = ['EpgUk','EpgUs','EpgEs','EpgDe','EpgMy','EpgHk']
pDialog = xbmcgui.DialogProgress()
guiDialog = xbmcgui.Dialog()


def AdultLock(name):
	if setting_true('plock'):
		tabo = ['adult','adults','porn','xxx','erotic','brazzers','hustler','redlight','red light','satisfaction']
		if any(s in name.lower() for s in tabo):
			plockcheck = KeyBoard(msg='Enter Code for parental lock')
			if str(plockcheck) == setting('plockcode'):
				return True
			else:
				return False
		else:
			return True
	else:
		return True

def DailyBoxingList(service_name):
	item_list = []
	from resources.lib.scrapers import LiveSat
	LiveSat.Scraper().Events(url='x-boxing-mma.php')
	for items in LiveSat.Scraper().events:
		EDT = DateTimeObject(items.get('eventDateTime'))
		if EDT <  DateTimeDelta(DateTimeNow(),h=24):
			item_list.append(('{}: {}'.format(items.get('eventDateTime'),items.get('eventName').encode('utf-8')),','.join(items.get('channels')),20,eval('{}_icon'.format(service_name))))
	from resources.lib.gui import dir_service
	d=dir_service.Dir_Service('Service_Dir.xml',addon_path,item_list=item_list,service_name=service_name,media_type='live')
	d.doModal()
	del d 

def DailyFoneList(service_name):
	item_list = []
	from resources.lib.scrapers import LiveSat
	LiveSat.Scraper().Events(url='x-formula1.php')
	for items in LiveSat.Scraper().events:
		EDT = DateTimeObject(items.get('eventDateTime'))
		if EDT <  DateTimeDelta(DateTimeNow(),h=24):
			item_list.append(('{}: {}'.format(items.get('eventDateTime'),items.get('eventName').encode('utf-8')),','.join(items.get('channels')),20,eval('{}_icon'.format(service_name))))
	from resources.lib.gui import dir_service
	d=dir_service.Dir_Service('Service_Dir.xml',addon_path,item_list=item_list,service_name=service_name,media_type='live')
	d.doModal()
	del d

def DailyFootballChannels(url,service_name):
	item_list = []
	duplicate = []
	livelistcheck = 0
	matches = 0 
	base_url = panelcalls.GetHostPort(service_name)
	from resources.lib.scrapers import LiveSoccerTV
	LiveSoccerTV.Scraper().ChannelList(url)
	livelist,livelistcount = panelcalls.GetEpgChannels(service_name,channeltype='live')
	pDialog.create('Searching for event matches')
	percent = 100.00/livelistcount
	for items in livelist:
		livelistcheck +=1
		pDialog.update(int(percent*livelistcheck),'Channels to check {} Channels Checked {} matches found {}'.format(livelistcount,livelistcheck,matches))
		itemname = items.get('name')
		itemid = items.get('streamid')
		if itemname.startswith('UK VIP'):
			itemname = itemname.replace('UK VIP','UK:')
		for channels in LiveSoccerTV.Scraper().List_Channel:
			channelname = channels.get('channel')
			channelcountry = ReplaceMulti(channels.get('country'),DSPL_country_replace)
			if FnMatch(itemname,'??:*'):
				itemcountry,itemchannel = itemname.split(':',1)
				if itemcountry not in country_ignore:
					if channelcountry.lower().strip() == itemcountry.lower().strip():
						itemchannel=ReplaceMulti(itemchannel,Channel_name_clean)
						ratio = difflib.SequenceMatcher(None,itemchannel.replace(' ',''),channels.get('channel').replace(' ','')).ratio()
						if ratio > 0.8:
							if GetDigit(itemchannel.encode('utf-8','ignore')) == GetDigit(channels.get('channel').encode('utf-8','ignore')):
								if itemid not in duplicate:
									matches+=1
									duplicate.append(itemid)
									item_list.append((itemname,'{}/live/{}/{}/{}.ts'.format(base_url,setting(str(service_name)+'username'),setting(str(service_name)+'password'),itemid),''))
			else:
				Itemname = ReplaceMulti(itemname,Channel_name_clean)
				ratio = difflib.SequenceMatcher(None,Itemname.replace(' ','').replace(' HD',''),channels.get('channel').replace(' ','')).ratio()
				if ratio > 0.98:
					if itemid not in duplicate:
						duplicate.append(itemid)
						matches+=1
						item_list.append((itemname,'{}/live/{}/{}/{}.ts'.format(base_url,setting(str(service_name)+'username'),setting(str(service_name)+'password'),itemid),''))
	pDialog.close()
	from resources.lib.gui import menu_live
	d=menu_live.Menu_Live(item_list,service_name)
	d.doModal()
	del d


def DailyFootballChannels_1(url,service_name):
	item_list = []
	duplicate = []
	ignorelist = ['Flow Sports App','TSN GO','beIN SPORTS CONNECT','beIN Sports Connect New Zealand','beIN Sports Connect Thailand']
	counrtyignore = ['italy']
	base_url = panelcalls.GetHostPort(service_name)
	from resources.lib.scrapers import LiveSoccerTV
	LiveSoccerTV.Scraper().ChannelList(url)
	livelist,count = panelcalls.GetEpgChannels(service_name,channeltype='live')
	Log(livelist)
	for items in livelist:
		if items.get('name').startswith('IN:') and 'Star sports' in items.get('name'):
			itemname = items.get('name').replace('Star sports','Star sports select')
		else:
			itemname = items.get('name')
		if ':' in itemname:
			itemname  = itemname.split(':',1)[1].strip()
		for channels in LiveSoccerTV.Scraper().List_Channel:
			if channels.get('country').lower() not in counrtyignore and channels.get('channel') not in ignorelist:
				ratio = difflib.SequenceMatcher(None, itemname.replace(' SD','').replace(' FHD','').replace(' HD','').replace(' ','').replace('1080P',''),channels.get('channel').replace(' ','')).ratio()
				if ratio == 1.0:
					if items.get('streamid') not in duplicate:
						duplicate.append(items.get('streamid'))
						item_list.append((items.get('name'),'{}/live/{}/{}/{}.ts'.format(base_url,setting(str(service_name)+'username'),setting(str(service_name)+'password'),items.get('streamid')),''))
				elif ratio > 0.75 and ratio < 1.0:
					if GetDigit(str(items.get('name').encode('utf-8','ignore'))) == GetDigit(str(channels.get('channel').encode('utf-8','ignore'))):
						if items.get('streamid') not in duplicate:
							duplicate.append(items.get('streamid'))
							item_list.append((items.get('name'),'{}/live/{}/{}/{}.ts'.format(base_url,setting(str(service_name)+'username'),setting(str(service_name)+'password'),items.get('streamid')),''))
	from resources.lib.gui import menu_live
	d=menu_live.Menu_Live(item_list,service_name)
	d.doModal()
	del d

def DailyFootballList(service_name):
	item_list = []
	from resources.lib.scrapers import LiveSoccerTV
	LiveSoccerTV.Scraper().FixtureList()
	sortedlist = sorted(LiveSoccerTV.Scraper().List_Fixtures, key=lambda k: k['date_time'])
	for items in sortedlist:
		item_list.append(('{} {}'.format(items.get('date_time'),items.get('eventName').encode('utf-8','ignore')),items.get('eventUrl'),18,eval('{}_icon'.format(service_name))))
	from resources.lib.gui import dir_service
	d=dir_service.Dir_Service('Service_Dir.xml',addon_path,item_list=item_list,service_name=service_name,media_type='live')
	d.doModal()
	del d

def DailyNflList(service_name):
	item_list = []
	from resources.lib.scrapers import LiveSat
	LiveSat.Scraper().Events(url='usa-nfl-football.php')
	for items in LiveSat.Scraper().events:
		EDT = DateTimeObject(items.get('eventDateTime'))
		if EDT <  DateTimeDelta(DateTimeNow(),h=24):
			item_list.append(('{}: {}'.format(items.get('eventDateTime'),items.get('eventName').encode('utf-8')),','.join(items.get('channels')),20,eval('{}_icon'.format(service_name))))
	from resources.lib.gui import dir_service
	d=dir_service.Dir_Service('Service_Dir.xml',addon_path,item_list=item_list,service_name=service_name,media_type='live')
	d.doModal()
	del d 



def DailyRugbyUList(service_name):
	item_list = []
	from resources.lib.scrapers import LiveSat
	LiveSat.Scraper().Events(url='x-rugby-union.php')
	for items in LiveSat.Scraper().events:
		EDT = DateTimeObject(items.get('eventDateTime'))
		if EDT <  DateTimeDelta(DateTimeNow(),h=24):
			item_list.append(('{}: {}'.format(items.get('eventDateTime'),items.get('eventName').encode('utf-8')),','.join(items.get('channels')),20,eval('{}_icon'.format(service_name))))
	from resources.lib.gui import dir_service
	d=dir_service.Dir_Service('Service_Dir.xml',addon_path,item_list=item_list,service_name=service_name,media_type='live')
	d.doModal()
	del d 

def DailySportChannels(url,service_name):
	item_list = []
	duplicate = []
	ignorelist = ['Flow Sports App','TSN GO','beIN SPORTS CONNECT','beIN Sports Connect New Zealand','ESPN+','beIN Sports Connect Thailand']
	counrtyignore = ['italy']
	CHANNELS = url.split(',')
	base_url = panelcalls.GetHostPort(service_name)
	livelist,livelistcount = panelcalls.GetEpgChannels(service_name,channeltype='live')
	for items in livelist:
		if items.get('name').startswith('IN:') and 'Star sports' in items.get('name'):
			itemname = items.get('name').replace('Star sports','Star sports select')
		else:
			itemname = items.get('name')
		if ':' in itemname:
			itemname  = itemname.split(':',1)[1].strip()
		for channels in CHANNELS:
			ratio = difflib.SequenceMatcher(None, itemname.replace(' SD','').replace(' FHD','').replace(' HD','').replace(' ','').replace('1080P',''),channels.replace(' ','')).ratio()
			if ratio == 1.0:
				if items.get('streamid') not in duplicate:
					duplicate.append(items.get('streamid'))
					item_list.append((items.get('name'),'{}/live/{}/{}/{}.ts'.format(base_url,setting(str(service_name)+'username'),setting(str(service_name)+'password'),items.get('streamid')),''))
			elif ratio > 0.75 and ratio < 1.0:
				if GetDigit(str(items.get('name').encode('utf-8','ignore'))) == GetDigit(str(channels.encode('utf-8','ignore'))):
					if items.get('streamid') not in duplicate:
						duplicate.append(items.get('streamid'))
						item_list.append((items.get('name'),'{}/live/{}/{}/{}.ts'.format(base_url,setting(str(service_name)+'username'),setting(str(service_name)+'password'),items.get('streamid')),''))
	from resources.lib.gui import menu_live
	d=menu_live.Menu_Live(item_list,service_name)
	d.doModal()
	del d

def DailySportList(service_name):
	item_list = [('Football',service_name,17,eval('{}_icon'.format(service_name))),('Rugby Union',service_name,19,eval('{}_icon'.format(service_name))),('Boxing and MMA',service_name,21,eval('{}_icon'.format(service_name))),('Motor Sport',service_name,22,eval('{}_icon'.format(service_name))),('NFL',service_name,23,eval('{}_icon'.format(service_name)))]
	from resources.lib.gui import dir_service
	d=dir_service.Dir_Service('Service_Dir.xml',addon_path,item_list=item_list,service_name=service_name,media_type='live')
	d.doModal()
	del d

def EpgDir(service_name):
	item_list = []
	icon = eval('{}_icon'.format(service_name))
	for Epg in Epgs:
		if setting_true(Epg):
			name = Epg.replace('Epg','').strip().upper()
			name2 = ReplaceMulti(name,epg_short_long_name)
			item_list.append((name,service_name,24,icon,name2))
	#if setting_true('EpgUs'):
	#	item_list.append(('US',service_name,24,icon))
	#if setting_true('EpgEs'):
	#	item_list.append(('ES',service_name,24,icon))
	from resources.lib.gui import dir_service
	d=dir_service.Dir_Service('Service_Dir.xml',addon_path,item_list=item_list,service_name=service_name,media_type='epg')
	d.doModal()
	del d

def GetLiveCat(service_name):
	icon = eval('{}_icon'.format(service_name))
	livecat = [('Sports Daily List','',16,icon)]
	base_url = panelcalls.GetHostPort(service_name)
	url = '{}/enigma2.php?username={}&password={}&type=get_live_categories'.format(base_url,setting(str(service_name)+'username'),setting(str(service_name)+'password'))
	Log(url)
	html = requests.get(url).text
	soup = BeautifulSoup(html, 'html.parser')
	channels = soup('channel')
	for channel in channels:
		title = channel('title')
		list_url = channel('playlist_url')
		livecat.append((bsixfour(title[0].text),list_url[0].text,12,icon))
	return livecat	

def GetLiveList(title,url):
	livelist = []
	if AdultLock(title):
		html = requests.get(url).text
		soup = BeautifulSoup(html, 'html.parser')
		channels = soup('channel')
		for channel in channels:
			vodtitle = channel('title')
			description = channel('description')
			streamurl = channel('stream_url')
			name = bsixfour(vodtitle[0].text)
			if '[' in name and ']' in name:
				name = name.split('[',1)[0]
			livelist.append((name,streamurl[0].text,bsixfour(description[0].text)))
	return livelist

def GetVodCat(service_name):
	icon = eval('{}_icon'.format(service_name))
	vodcat = [('Search Video On Demand',service_name,8,icon)]
	base_url = panelcalls.GetHostPort(service_name)
	url = '{}/enigma2.php?username={}&password={}&type=get_vod_categories'.format(base_url,setting(str(service_name)+'username'),setting(str(service_name)+'password'))
	Log(url)
	html = requests.get(url).text
	soup = BeautifulSoup(html, 'html.parser')
	channels = soup('channel')
	for channel in channels:
		title = channel('title')
		list_url = channel('playlist_url')
		vodcat.append((bsixfour(title[0].text),list_url[0].text,14,icon))
	return vodcat

def GetVodList(title,url):
	vodlist = []
	if AdultLock(title):
		html = requests.get(url).text
		soup = BeautifulSoup(html, 'html.parser')
		channels = soup('channel')
		percent = 100.00/len(channels)
		pDialog.create(heading='Collecting {} movies'.format(title) if not title.lower().endswith(('movie' ,'movies' )) else 'Collecting {}'.format(title))
		count = 0
		for channel in channels:
			iD = ''
			count +=1
			vodtitle = channel('title')
			pDialog.update(int(count*percent),'Adding {} ({} of {})'.format(bsixfour(vodtitle[0].text),count,len(channels)))
			icon = channel('desc_image')
			description = channel('description')
			streamurl = channel('stream_url')
			if setting_true('tmdbmeta'):
				from resources.lib.modules import tmdb_api
				description = bsixfour(description[0].text)
				if 'KINOPOISK_ID' in description:
					iDs = re.compile('KINOPOISK_ID:(.+?)\n').findall(str(description))
					if len(iDs)>0:
						iD = iDs[0].strip()
					else: iD = ''
				if 'TMDB_ID' in description and iD == '': 
					iDs = re.compile('TMDB_ID:(.+?)\n').findall(str(description))
					if len(iDs)>0:
						iD = iDs[0].strip()
					else: iD = ''
					Log(iD)
				if 'IMDB_ID' in description and iD == '':
					remove= re.compile(r'(\d\d\d\d)').findall(base64.b64decode(vodtitle[0].text))
					if len(remove)>0:
						cleantitle = (bsixfour(vodtitle[0].text)).replace(remove[0],'')
					else: cleantitle = bsixfour(vodtitle[0].text)
					cleantitle=cleantitle.replace('Bluray','').replace('Hdcam','').replace('HDCAM','').replace('CAM','').strip()
					Date = re.compile('RELEASEDATE:(.+?)\n').findall(description)
					try:
						Year = dparser.parse(Date[0],fuzzy=True).strftime('%Y')
					except ValueError:
						if len(remove) > 0:
							Year = remove[0]
						else:
							Year = None
					if Year != None:
						iD = str(tmdb_api.SearchMovie(cleantitle,Year))
					else:
						iD = ''
				if iD.isdigit():
					title,poster_path,backdrop_path,overview,release_date,Genres = tmdb_api.MovieMetaData(iD)
					vodlist.append((title.encode('utf8','ignore'),streamurl[0].text,7,poster_path,backdrop_path,overview.encode('utf8','ignore'),release_date,Genres))
				else:
					vodlist.append((bsixfour(vodtitle[0].text),streamurl[0].text,7,icon[0].text,'','','','',''))
			else:
				vodlist.append((bsixfour(vodtitle[0].text),streamurl[0].text,7,icon[0].text,'','','','',''))
		pDialog.close()
		return vodlist

def MenuLive(service_name,title,url):
	livelist = GetLiveList(title,url)
	from resources.lib.gui import menu_live
	d=menu_live.Menu_Live(livelist,service_name,title=title,url=url)
	d.doModal()
	del d


class Menu_Live(xbmcgui.WindowXML):

	ACTION_SELECT_ITEM      = 7
	ACTION_NAV_BACK         = 92
	ACTION_MOUSE_LEFT_CLICK = 100
	MYACCOUNT               = 101
	SETTING                 = 102
	SELECTSERVICE           = 103
	BACK                    = 104


	def __init__(self,*args,**kwargs):
		self.WINDOW =xbmcgui.Window( 10000 )
		self.SERVICENAME = kwargs.get('service_name')
		self.LISTITEM = kwargs.get('item_list')
		self.TITLE = kwargs.get('title')
		self.URL = kwargs.get('url')

	def onInit(self):
		self.control_list = self.getControl(201)
		if not self.control_list.size() > 0: 
			for item in self.LISTITEM:
				label         = item[0]
				url           = item[1]
				description   = item[2]
				icon = eval('{}_icon'.format(self.SERVICENAME))
				url=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
				ItemList = xbmcgui.ListItem(label,path=url,thumbnailImage=icon)
				ItemList.setInfo('video',{ 'plot':description})
				ItemList.setProperty('IsPlayable','true')
				ItemList.setProperty('IsFolder','false')
				self.control_list.addItem(ItemList)
		self.setFocusId(201)

	def onFocus(self, control):
		Log('onFocus: {}'.format(control))
		pass

	def onAction(self,action):
		Log('Action: %s' % (action.getId()))
		if action == self.ACTION_SELECT_ITEM or action == self.ACTION_MOUSE_LEFT_CLICK:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus %s Pos %s'%(ActionID,PosID))
			if ActionID == 201:
				PosID = self.control_list.getSelectedPosition()
				label = self.LISTITEM[PosID][0]
				url = self.LISTITEM[PosID][1]
				RunModule(url=url,mode=13,name=label)
		elif action == self.ACTION_NAV_BACK:
			self.close()

	def onClick(self,control):
		Log('onClick {}'.format(control))
		if control == self.BACK:
			self.close()
		elif control == self.MYACCOUNT:
			AccountInfo(self.SERVICENAME)
		elif control == self.SETTING:
			OpenSettings()
		elif control == self.SELECTSERVICE:
			MyServicesLoad()
			

def MenuVod(service_name,title,url):
	vodlist = GetVodList(title,url)
	d=Menu_Vod('Vod_Menu.xml',addon_path,item_list=vodlist,service_name=service_name,title=title,url=url)
	d.doModal()
	del d

class Menu_Vod(xbmcgui.WindowXML):

	ACTION_SELECT_ITEM      = 7
	ACTION_NAV_BACK         = 92
	ACTION_MOUSE_LEFT_CLICK = 100
	MYACCOUNT               = 101
	SETTING                 = 102
	SELECTSERVICE           = 103
	BACK                    = 104



	def __init__(self,*args,**kwargs):
		self.WINDOW =xbmcgui.Window( 10000 )
		self.LISTITEM = kwargs.get('item_list')
		self.SERVICENAME = kwargs.get('service_name')
		self.URL = kwargs.get('url')
		self.TITLE = kwargs.get('title')
		self.WINDOW.setProperty('COLOR',self.SERVICENAME)

	def onInit(self):
		self.control_list = self.getControl(201)
		if not self.control_list.size() > 0: 
			for item in self.LISTITEM:
				label       = item[0]
				url         = item[1]
				mode        = item[2]
				icon        = item[3]
				backdrop    = item[4] 
				description = item[5]
				date        = item[6]
				genres      = item[7]
				if icon == '' or icon == None or len(icon) <=1:
					icon = eval('{}_icon'.format(self.SERVICENAME))
				if backdrop == '' or backdrop == None:
					backdrop = addon_fanart
				url=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
				ItemList = xbmcgui.ListItem(label,path=url)
				ItemList.setInfo('video',{ 'plot':description,'genre':genres,'premiered':date})
				ItemList.setArt({'icon':icon,'fanart':fanart})
				ItemList.setProperty( "Fanart_Image", backdrop )
				ItemList.setProperty('IsPlayable','true')
				ItemList.setProperty('IsFolder','false')
				self.control_list.addItem(ItemList)
		self.setFocusId(201)

	def onFocus(self, control):
		Log('onFocus: {}'.format(control))
		pass

	def onAction(self,action):
		Log('Action: {}'.format(action.getId()))
		if action == self.ACTION_SELECT_ITEM or action == self.ACTION_MOUSE_LEFT_CLICK:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus %s Pos %s'%(ActionID,PosID))
			if ActionID == 201:
				PosID = self.control_list.getSelectedPosition()
				label = self.LISTITEM[PosID][0]
				url = self.LISTITEM[PosID][1]
				RunModule(url=url,mode=13,name=label)
		elif action == self.ACTION_NAV_BACK:
			self.close()

	def onClick(self,control):
		Log('onClick {}'.format(control))
		if control == self.BACK:
			self.close()
		elif control == self.MYACCOUNT:
			AccountInfo(self.SERVICENAME)
		elif control == self.SETTING:
			OpenSettings()
		elif control == self.SELECTSERVICE:
			MyServicesLoad()

def MyEpgList():
	i = list()
	for Epg in Epgs:
		if setting_true('{}'.format(Epg)):
			i.append(Epg)
	return i 

def MyServicesSet():
	for Service in Services:
		if setting_true('{}enable'.format(Service)):
			if panelcalls.CheckAccount(Service):
				if not setting_true('{}enabled'.format(Service)):
					setting_set('{}enabled'.format(Service),'true')
			else:
				if setting_true('{}enabled'.format(Service)):
					setting_set('{}enabled'.format(Service),'false')
		else:
			if setting_true('{}enabled'.format(Service)):
					setting_set('{}enabled'.format(Service),'false')

def MyServices():
	a = []
	for Service in Services:
		if setting_true('{}enabled'.format(Service)):
			if Service not in a:
				a.append(Service)
	return a 

def MyServicesLoad():
	MyServicesSet()
	ServiceList = MyServices()
	EpgList = MyEpgList()
	p = 100.00/(len(ServiceList)*len(EpgList)*2) if len(EpgList)>0 and len(ServiceList)>0 else 1
	c = 0
	if len(ServiceList) == 0:
		OpenSettings()
	else:
		if int(setting('getepgdata')) == 1:
			pDialog.create('Loading EPG Files')
			CreateDir(epg_folder)
			from resources.lib.modules import epg_source
			for Service in ServiceList:
				c+=1
				epg_source.GetServiceXmlTv(Service)
				pDialog.update(c*int(p),line1='Getting EPG for {}'.format(Service.capitalize()))
			for Epg, Service in [(Epg,Service) for Epg in EpgList for Service in ServiceList]:
				c+=1
				country = Epg.lower().replace('epg','').strip()
				pDialog.update(c*int(p),line3='Path {}'.format(eval('{}_epg_folder'.format(country.lower()))))
				CreateDir(eval('{}_epg_folder'.format(country.lower())))
				pDialog.update(c*int(p),line2='Creating Custom Guide for {} {}'.format(Service.capitalize(),country.upper()),line3='Path {}'.format(eval('{}_{}_EPG_XML'.format(Service.upper(),country.upper()))).replace(USERDATA,''))
				epg_source.CustomXMLTV(service_name=Service,epg_country=country)
			pDialog.close()
		from resources.lib.gui import select_service
		d=select_service.Select_Service()
		d.doModal()
		del d


def OpenService(service_name):
	Log(service_name)
	from resources.lib.gui import home_service
	d=home_service.Home_Service(service_name)
	d.doModal()
	del d


class ProgressDialog(object):

	dialog = None
	def __init__(self):
		#self.dialog = DialogProgress.Window('Progress_Dialog.xml', addon_path)
		dialog = None
	def create(self,header,line1='',line2='',line3='',service_name=''):
		self.dialog = ProgressDialog.Window('Progress_Dialog.xml', addon_path)
		self.dialog.show()
		self.dialog.setHeading(header)
		self.dialog.setLine1(line1)
		self.dialog.setLine2(line2)
		self.dialog.setLine3(line3)
		self.dialog.setColor(service_name)
		#self.dialog.doModal()

	def update(self,percent,line1='',line2='',line3=''):
		if self.dialog is not None:
			self.dialog.setProgress(percent)
			self.dialog.setLine1(line1)
			self.dialog.setLine2(line2)
			self.dialog.setLine3(line3)

	def iscanceled(self):
		if self.dialog is not None:
			return self.dialog.cancel
		else:
			return False

	def close(self):
		if self.dialog is not None:
			self.dialog.close()
			del self.dialog


	def Cancel(self):
		if self.dialog is not None:
			if self.dialog.cancel == True:
				return True
			else:
				return False

	class Window(xbmcgui.WindowXMLDialog):

		HEADING_CTRL = 101
		LINE1_CTRL   = 10
		LINE2_CTRL   = 11
		LINE3_CTRL   = 12
		PROGRESS_CTRL = 20
		CLOSE         = 107

		def onInit(self):
			pass

		def onClick(self,control):
			Log('onClick {}'.format(control))
			if control == self.CLOSE:
				self.close()

		def setColor(self,color):
			self.setProperty('COLOR',color)

		def setHeading(self, header):
			self.setLabel(self.HEADING_CTRL, header)

		def setProgress(self, progress):
			self.getControl(self.PROGRESS_CTRL).setPercent(progress)

		def setLine1(self, line):
			self.setLabel(self.LINE1_CTRL, line)

		def setLine2(self, line):
			self.setLabel(self.LINE2_CTRL, line)

		def setLine3(self, line):
			self.setLabel(self.LINE3_CTRL, line)

		def setLabel(self, ctrl, line):
			self.getControl(ctrl).setLabel(line)

def PreLoadActions():
	if setting_true('clear_all_epg_data') and int(setting('getepgdata')) == 1:
		DelAllContents(epg_folder)
		setting_set('clear_all_epg_data','false')
	if len(sys.argv) > 1:
		category = sys.argv[1]
		if category:
			setting_set('category',category)
	channel = ""
	if len(sys.argv) > 3:
		channel = sys.argv[3]
	setting_set('channel.arg',channel)
	CopyFile(actionsjs,profile_actionsjs)
	if not xbmcvfs.exists(epg_folder):
		xbmcvfs.mkdir(epg_folder)

def SearchVod(service_name):
	vodlist = GetSearchVodList(service_name)
	d=Menu_Vod('Vod_Menu.xml',addon_path,item_list=vodlist,service_name=service_name)
	d.doModal()
	del d

def GetSearchVodList(service_name):
	vodlist = []
	query = KeyBoard(msg='')
	base_url = panelcalls.GetHostPort(service_name)
	url = '{}/enigma2.php?username={}&password={}&type=get_vod_categories'.format(base_url,setting(str(service_name)+'username'),setting(str(service_name)+'password'))
	playlistUrl = []
	html = requests.get(url).text
	soup = BeautifulSoup(html, 'html.parser')
	if soup.find_all('playlist_url'):
		channels = soup('channel')
		for channel in channels:
			playlist = channel('playlist_url')
			playlistUrl.append( playlist[0].text)
	totalpage = len(playlistUrl)
	percent = int(100.00/totalpage)
	pagecount = 0
	matchitems = 0
	titlematch = []
	pDialog.create(heading='Searching for \"{}\"'.format(query))
	for url in playlistUrl:
		pagecount += 1
		pDialog.update(percent*pagecount,'Searching page {} of {} matches found {}'.format(pagecount,totalpage,matchitems))
		html2 = requests.get(url).text
		soup2 = BeautifulSoup(html2,'html.parser')
		if soup2.find_all('stream_url'):
			channels = soup2('channel')
			for channel in channels:
				iD = ''
				title = channel('title')
				title = base64.b64decode(title[0].text)
				if query.lower() in title.lower():
					if title not in titlematch:
						titlematch.append(title)
						matchitems += 1
						pDialog.update(percent*pagecount,'Searching page {} of {} matches found {}'.format(pagecount,totalpage,matchitems))
						streamurl = channel('stream_url')
						icon = channel('desc_image')
						description = channel('description')
						if setting_true('tmdbmeta'):
							from resources.lib.modules import tmdb_api
							description = bsixfour(description[0].text)
							if 'KINOPOISK_ID' in description:
								iDs = re.compile('KINOPOISK_ID:(.+?)\n').findall(str(description))
								if len(iDs)>0:
									iD = iDs[0].strip()
								else: iD = ''
							if 'TMDB_ID' in description and iD == '': 
								iDs = re.compile('TMDB_ID:(.+?)\n').findall(str(description))
								if len(iDs)>0:
									iD = iDs[0].strip()
								else: iD = ''
								Log(iD)
							if 'IMDB_ID' in description and iD == '':
								remove= re.compile('(\d\d\d\d)').findall(str(title))
								cleantitle = title.replace(remove[0],'').replace('Bluray','').replace('Hdcam','').replace('HDCAM','').replace('CAM','').strip()
								Date = re.compile('RELEASEDATE:(.+?)\n').findall(description)
								try:
									Year = dparser.parse(Date[0],fuzzy=True).strftime('%Y')
								except ValueError:
									if len(remove) > 0:
										Year = remove[0]
									else:
										Year = None
								if Year != None:
									iD = str(tmdb_api.SearchMovie(cleantitle,Year))
								else:
									iD = ''
							if iD.isdigit():
								title,poster_path,backdrop_path,overview,release_date,Genres = tmdb_api.MovieMetaData(iD)
								vodlist.append((title.encode('utf8','ignore'),streamurl[0].text,7,poster_path,backdrop_path,overview.encode('utf8','ignore'),release_date,Genres))
							else:
								vodlist.append((title,streamurl[0].text,7,icon[0].text,'','','','',''))
						else:
							vodlist.append((title,streamurl[0].text,7,icon[0].text,'','','','',''))
	pDialog.close()
	return vodlist

def ServiceDir(service_name,media):
	livecat = GetLiveCat(service_name)
	vodcat  = GetVodCat(service_name)
	cat = eval('{}cat'.format(media))
	from resources.lib.gui import dir_service
	d=dir_service.Dir_Service('Service_Dir.xml',addon_path,item_list=cat,service_name=service_name,media_type=media)
	d.doModal()
	del d					


def StreamPlay(label,url):
	player = XbmcPlayer()
	listitem = xbmcgui.ListItem( label = label, path=url )
	player.play(url,listitem)

			
xbmcplugin.setContent(int(sys.argv[1]), 'movies')

try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_UNSORTED)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATE)
except:
    pass
try:
    xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_GENRE)
except:
    pass

params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass


if mode==None:
	Log('excuting pre load actions')
	PreLoadActions()
	Log('Checking and setting MyServices')
	MyServicesLoad()
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
elif mode==1:
	Log('OpenService')
	OpenService(url)
elif mode==2:
	Log('Live Tv Cat Get url = {}'.format(url))
	GetLiveCat(url)
elif mode==3:
	Log('VOD Cat get')
	GetVodCat(url)
elif mode==4:
	Log('Opening account info')
	AccountInfo(url)
elif mode==5:
	Log('OpenSettings')
	OpenSettings()
elif mode==6:
	Log('Getting VOD cat lists')
	GetVodList(name,url)
elif mode==7:
	Log('Play stream {}'.format(url))
	item = xbmcgui.ListItem(label=name,path=url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
elif mode==8:
	Log('searching vod url {} mode {}'.format(url,mode))
	SearchVod(url)
elif mode==9:
	Log('selecting another service')
	refresh_container()
	time.sleep(500)
	MyServicesLoad()
elif mode==10:
	Log('Live Tv List Get')
	GetLiveList(name,url)
elif mode==11:
	Log('Open service {} {} {}'.format(name,url,mode))
	ServiceDir(name,url)
elif mode==12:
	Log('Open Live menu {} {} {} {}'.format(name,url,mode,description))
	MenuLive(description,name,url)
elif mode==13:
	Log('Playing {} {}'.format(name,url))
	StreamPlay(name,url)
elif mode==14:
	Log('Opening Vod menu {} {} {} {}'.format(name,url,mode,description))
	MenuVod(description,name,url)
elif mode==15:
	Log('Open EPG menu {} {} {} {}'.format(name,url,mode,description))
	EpgDir(name)
elif mode==16:
	Log('Opening DailySportList name={},url={},mode={},description={}'.format(name,url,mode,description))
	DailySportList(description)
elif mode==17:
	Log('Opening DailyFootballList name={},url={},mode={},description={}'.format(name,url,mode,description))
	DailyFootballList(description)
elif mode==18:
	Log('Opening selected DailyFootballList name={},url={},mode={},description={}'.format(name,url,mode,description))
	DailyFootballChannels(url,description)
elif mode==19:
	Log('Opening DailyRugbyUList name={},url={},mode={},description={}'.format(name,url,mode,description))
	DailyRugbyUList(description)
elif mode==20:
	Log('Opening DailyList channel name={},url={},mode={},description={}'.format(name,url,mode,description))
	DailySportChannels(url,description)
elif mode==21:
	Log('Opening DailyBoxingList  name={},url={},mode={},description={}'.format(name,url,mode,description))
	DailyBoxingList(description)
elif mode==22:
	Log('Opening DailyFoneList  name={},url={},mode={},description={}'.format(name,url,mode,description))
	DailyFoneList(description)
elif mode==23:
	Log('Opening DailyNflList name={},url={},mode={},description={}'.format(name,url,mode,description))
	DailyNflList(description)
elif mode==24:
	Log('Opening EPG name={},url={},mode={},description={}'.format(name,url,mode,description))
	import tvguide
	tvguide.EPG_DATA.extend((name,url))
	w=tvguide.TVGuide()
	w.doModal()
	del w
elif mode==1000:
	Log('test progress bar')
	ProgressDialog().create(header='header',line1='line 1',line2='line 2',line3='line 3',service_name='green')
	xbmc.sleep(2000)
	Log('awake from sleep')
	ProgressDialog().update(percent=10,line1='line 1 line 1',line2='line 2 line 2',line3='line 3 line 3')
	xbmc.sleep(2000)
	ProgressDialog().Close()
xbmcplugin.endOfDirectory(int(sys.argv[1]))
