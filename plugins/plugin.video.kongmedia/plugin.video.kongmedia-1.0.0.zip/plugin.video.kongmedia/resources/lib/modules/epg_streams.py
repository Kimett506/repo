# -*- coding: utf-8 -*-

from resources.lib.modules._addon import *
from resources.lib.modules._common import Log
from resources.lib.modules import panelcalls


class EpgStreams():

	match = list()

	def __init__(self,service_name,channel):
		Log(channel)
		self.service_name = service_name
		self.items,self.itemscount = panelcalls.GetEpgChannels(service_name,channeltype='live')
		self.channelID = channel.id
		self.key = 'epg_channel_id'
		self.channelmatch = self.FindMatches(self.key,self.channelID,self.items)
		Log(self.channelmatch)
		self.CreateList(self.channelmatch)


	def FindMatches(self,key,match,List):
		Match = filter(lambda x:x[key] == match,List)
		return Match

	def CreateList(self,items):
		for item in items:
			Log(item)
			name = item.get('name')
			streamid = item.get('streamid')
			playUrl = '{}:{}/live/{}/{}/{}.ts'.format(eval('{}_host'.format(self.service_name.lower())),eval('{}_port'.format(self.service_name.lower())),setting('{}username'.format(self.service_name.lower())),setting('{}password'.format(self.service_name.lower())),streamid)
			self.match.append((name,playUrl))

