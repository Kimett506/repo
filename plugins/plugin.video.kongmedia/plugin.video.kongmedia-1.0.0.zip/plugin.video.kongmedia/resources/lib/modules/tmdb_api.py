import requests

from resources.lib.modules._addon import *

artwork_url = 'https://image.tmdb.org/t/p/original{}'
base_url    = 'https://api.themoviedb.org/3'
tmdb_apikey = setting('tmdbapi')
adult_content = setting('tmdbadult')


def MovieMetaData(ID):
	Genres = []
	url = "{}/movie/{}?api_key={}".format(base_url,ID,tmdb_apikey)
	r = requests.get(url)
	data = r.json()
	poster_path = artwork_url.format(data.get('poster_path'))
	backdrop_path = artwork_url.format(data.get('backdrop_path'))
	title = data.get('title',data.get('original_title','Title Missing'))
	overview = data.get('overview','')
	release_date = data.get('release_date')
	genres = data.get("genres")
	if genres != None:
		for genre in genres:
			Genres.append(genre.get('name'))
	return title,poster_path,backdrop_path,overview,release_date,Genres


def SearchMovie(query,year=''):
	#returns 1st movie from search list
	if year != '':
		url = '{}/search/movie?api_key={}&query={}&page=1&year={}&include_adult={}'.format(base_url,tmdb_apikey,query,year,adult_content)
	else:
		url = '{}/search/movie?api_key={}&query={}&page=1&include_adult={}'.format(base_url,tmdb_apikey,query,adult_content)
	r = requests.get(url)
	data = r.json()
	results = data.get('results')
	if not results == None and len(results) > 0:
		iD = results[0].get('id')
	else: iD = ''
	return iD

def SearchMulti(query):
	#returns 1st item from multilist
	url = '{}/search/multi?api_key={}&query={}&page=1&include_adult={}'.format(base_url,tmdb_apikey,query,adult_content)
	r = requests.get(url)
	d = r.json()
	rs = d.get('results')
	if not rs == None and len(rs)>0:
		iD = rs[0].get('id')
		media_type = rs[0].get('media_type')
	else:
		iD = ''
		media_type = ''
	return iD,media_type


def SearchTv(query):
	#returns 1st Tv show from search list 
	url = '{}/search/tv?api_key={}&query={}&page=1&include_adult={}'.format(base_url,tmdb_apikey,query,adult_content)
	r = requests.get(url)
	data = r.json()
	results = data.get('results')
	if not results == None and len(results) > 0:
		iD = results[0].get('id')
	else: iD = ''
	return iD

def SearchQuery(query,query_type,page=1):
	url = '{}/search/{}?api_key={}&query={}&page={}&include_adult={}'.format(base_url,query_type,tmdb_apikey,query,page,adult_content)
	r = requests.get(url)
	data = r.json()
	results = data.get('results')
	return results

def TvMetaData(ID):
	url ='{}/tv/{}?api_key={}&include_adult={}'.format(base_url,ID,tmdb_apikey,adult_content)
	r = requests.get(url)
	d = r.json()
	original_name = d.get('original_name')
	overview = d.get('overview')
	poster_path = artwork_url.format(d.get('poster_path'))
	backdrop_path = artwork_url.format(d.get("backdrop_path"))
	return original_name,overview,poster_path,backdrop_path

def TvShowMetaData(ID,season,episode):
	url = '{}/tv/{}/season/{}/episode/{}?api_key={}&include_adult={}'.format(base_url,ID,season,episode,tmdb_apikey,adult_content)
	r = requests.get(url)
	d = r.json()
	still_path = artwork_url.format(d.get('still_path')) 
	name = d.get('name','Title Missing')
	air_date = d.get('air_date')
	overview = d.get('overview')
	episode_number = d.get("episode_number")
	season_number = d.get("season_number")
	return name,still_path,air_date,overview,episode_number,season_number