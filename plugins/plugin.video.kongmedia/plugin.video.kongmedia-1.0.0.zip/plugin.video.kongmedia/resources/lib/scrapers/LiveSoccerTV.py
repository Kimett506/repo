import datetime
import dateutil.parser as dparser
from dateutil import tz
import pytz
import re
import requests



class Scraper():

	BaseUrl       = 'https://www.livesoccertv.com'
	headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0'}
	Ignore_list = ['Flow Sports App','TSN GO','beIN SPORTS CONNECT','beIN Sports Connect New Zealand','ESPN+','beIN Sports Connect Thailand']
	List_Fixtures = []
	List_Channel  = []

	def __init__(self):
		pass

	def FixtureList(self):
		html = requests.get(self.BaseUrl,headers=self.headers).text
		match = re.compile('<tr id=(.+?)</tr>',re.DOTALL).findall(html)
		matchdate = re.compile('<tr class="livecomp">.+?<a.+?>(.+?)</a>',re.DOTALL).findall(html)
		for block in match:
			match2 = re.compile(r'df=\'H:MM\'>(.+?)</span>.+?href="(.+?)" title="(.+?)"',re.DOTALL).findall(block)
			for Time,eventUrl,eventName in match2:
				Time = '{} -04:00'.format(Time)
				Time = dparser.parse(Time,fuzzy=True)
				Date = dparser.parse(matchdate[0])
				LOC_TZ = tz.tzlocal()
				LOC_T = Time.astimezone(LOC_TZ)
				LOC_DT = LOC_T.replace(year=Date.year, month=Date.month, day=Date.day)
				self.List_Fixtures.append({'date_time':LOC_DT.strftime('%Y-%m-%d %H:%M'),'eventUrl':'{}{}'.format(self.BaseUrl,eventUrl),'eventName':eventName})


	def ChannelList(self,url):
		html = requests.get(url,headers=self.headers).text
		match = re.compile('<table id="wc_channels"(.+?)</table>',re.DOTALL).findall(html)
		for block in match:
			match2 = re.compile('<tr>(.+?)</tr>',re.DOTALL).findall(block)
			for block2 in match2:
				countrymatch = re.compile('<span class=".+?">(.+?)</span>',re.DOTALL).findall(block2)
				if len(countrymatch) == 0:
					pass
				else:
					match3 = re.compile('<a href="/channels.+?title="(.+?)".+?>',re.DOTALL).findall(block2)
					for channel in match3:
						if channel not in self.List_Channel:
							self.List_Channel.append({'country':countrymatch[0],'channel': channel})


	