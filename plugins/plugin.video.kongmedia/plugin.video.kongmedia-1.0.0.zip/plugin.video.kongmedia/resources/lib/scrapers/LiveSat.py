from bs4 import BeautifulSoup
import requests
import re 
from datetime import date,timedelta
import dateutil.parser as dparser
import dateutil.relativedelta as ddelta

from resources.lib.modules._common import Log




class Scraper():

	base_url = 'https://liveonsat.com/'
	events = []
	headers = {'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0'}

	def __init__(self):
		pass

	def Events(self,url):
		Url = self.base_url+url
		html = requests.Session() 
		html = html.get(Url).text
		match = re.compile('<h2 class = time_head>(.+?)<div class=floatAndClearL_list>',re.DOTALL).findall(html)
		for block in match:
			soup = BeautifulSoup('<h2 class = time_head>'+block, 'html.parser')
			eventDate = soup.find('h2',attrs={'class': 'time_head'}).text
			block_fixs = soup.find_all('div',attrs={'class': 'blockfix'})
			for blockfix in block_fixs:
				channels =[]
				eventTime = blockfix('div' ,attrs={'class': 'fLeft_time_live'})[0].text.replace('ST:','')
				eventDateTime = '{} {}'.format(eventDate,eventTime)
				eventDateTime = dparser.parse(eventDateTime)
				if eventDateTime.date() < date.today()+timedelta(days=-1):
					eventDateTime = eventDateTime+ddelta.relativedelta(years=1)
				eventName = blockfix('div',attrs={'class': 'fLeft'})[0].text
				tables = blockfix.find_all('table')
				for table in tables:
					channels.append(table.text.strip().encode('utf-8'))
				self.events.append({'eventDateTime':eventDateTime.strftime('%Y-%m-%d %H:%M'),'eventName':eventName.strip(),'channels':channels})