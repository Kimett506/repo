# -*- coding: utf-8 -*-

import xbmcgui

from resources.lib.modules._addon import *
from resources.lib.modules._common import *



class Select_Service(xbmcgui.WindowXML):

	ACTION_SELECT_ITEM      = 7
	ACTION_NAV_BACK         = 92
	ACTION_MOUSE_LEFT_CLICK = 100
	SETTING                 = 102
	CLOSE                   = 105
	QUICKLINKS              = 106

	def __new__(cls):
		return super(Select_Service, cls).__new__(cls, 'Service_Select.xml', addon_path)

	def __init__(self,*args,**kwargs):
		super(Select_Service,self).__init__()
		self.LISTITEM = [('Gold','gold',1,gold_icon),('Green','green',1,green_icon),('Red','red',1,red_icon)]

	def onInit(self):
		self.control_list = self.getControl(201)
		if not self.control_list.size() > 0: 
			for item in self.LISTITEM:
				label  = item[0]
				url    = item[1]
				mode   = item[2]
				icon   = item[3]
				url=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
				ItemList = xbmcgui.ListItem(label,path=url,thumbnailImage=icon)
				self.control_list.addItem(ItemList)
		xbmcplugin.endOfDirectory(int(sys.argv[1]))
		self.setFocusId(201)


	def onFocus(self, control):
			Log('onFocus: {}'.format(control))
			pass

	def onClick(self, control):
		Log('onClick: {}'.format(control))
		if control == self.CLOSE:
			xbmc.executebuiltin('XBMC.ActivateWindow(Home)')
		elif control == self.SETTING:
			OpenSettings()
		elif control == self.QUICKLINKS:
			import quicklinks
			d=quicklinks.QuickLinks(None)
			d.doModal()
			del d
			
	def onAction(self,action):
		Log('Action: %s' % (action.getId()))
		if action == self.ACTION_SELECT_ITEM or action == self.ACTION_MOUSE_LEFT_CLICK:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus {} Pos {}'.format(ActionID,PosID))
			if ActionID == 201:
				PosID = self.control_list.getSelectedPosition()
				label = self.LISTITEM[PosID][0]
				url = self.LISTITEM[PosID][1]
				mode = self.LISTITEM[PosID][2]
				icon = self.LISTITEM[PosID][3]
				if setting_true('{}enabled'.format(url)):
					RunModule(url=url,mode=int(mode),name=label)
				else:
					Notify(message='{} Service not Enabled'.format(label),icon=eval('{}_icon'.format(url)))
		elif action == self.ACTION_NAV_BACK:
			xbmc.executebuiltin('XBMC.ActivateWindow(Home)')
