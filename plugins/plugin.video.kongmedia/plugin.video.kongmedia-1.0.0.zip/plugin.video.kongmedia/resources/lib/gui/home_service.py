# -*- coding: utf-8 -*-

import xbmcgui

from resources.lib.modules._addon import *
from resources.lib.modules._common import *



class Home_Service(xbmcgui.WindowXML):

	MYACCOUNT     = 101
	SETTING       = 102
	SELECTSERVICE = 103
	CLOSE         = 105
	QUICKLINKS    = 106

	ACTION_MOUSE_LEFT_CLICK = 100
	ACTION_PREVIOUS_MENU    = 10
	ACTION_SELECT_ITEM      = 7
	ACTION_BACK             = 92
	ACTION_NAV_BACK         = 92

	def __new__(cls,service_name):
		return super(Home_Service, cls).__new__(cls, 'Service_Home.xml', addon_path)

	def __init__(self,service_name,*args,**kwargs):
		super(Home_Service,self).__init__()
		self.SERVICENAME = service_name
		self.LISTITEM = [('EPG',service_name,1,eval('{}_icon'.format(service_name))),('Live TV',service_name,2,eval('{}_icon'.format(service_name))),('Video On Demand',service_name,3,eval('{}_icon'.format(service_name)))]
		self.setColor(self.SERVICENAME)

	def onInit(self):
		self.control_list = self.getControl(201)
		for item in self.LISTITEM:
			label  = item[0]
			url    = item[1]
			mode   = item[2]
			icon   = item[3]
			url=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
			ItemList = xbmcgui.ListItem(label,path=url,thumbnailImage=icon)
			self.control_list.addItem(ItemList)
		self.setFocusId(201)

	def onClick(self, control):
		Log('onClick: {}'.format(control))
		if control == self.MYACCOUNT:
			from resources.lib.gui import dialog_text
			d=dialog_text.Account_Info(self.SERVICENAME)
			d.doModal()
			del d 
		elif control == self.SETTING:
			OpenSettings()
		elif control == self.SELECTSERVICE:
			from resources.lib.gui import select_service
			d=select_service.Select_Service()
			d.doModal()
			del d
		elif control == self.CLOSE:
			self.close()
			xbmc.executebuiltin('XBMC.ActivateWindow(Home)')
		elif control == self.QUICKLINKS:
			from resources.lib.gui import quicklinks
			d=quicklinks.QuickLinks(self.SERVICENAME)
			d.doModal()
			del d 

	def onAction(self,action):
		Log('Action: %s' % (action.getId()))
		if action == self.ACTION_SELECT_ITEM or action == self.ACTION_MOUSE_LEFT_CLICK:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus %s Pos %s'%(ActionID,PosID))
			if ActionID == 201:
				if self.control_list.getSelectedPosition() == 0:
					RunModule(url='epg',mode=15,name=self.SERVICENAME)
				elif self.control_list.getSelectedPosition() == 1:
					RunModule(url='live',mode=11,name=self.SERVICENAME)
				elif self.control_list.getSelectedPosition() == 2:
					RunModule(url='vod',mode=11,name=self.SERVICENAME)
		elif action == self.ACTION_NAV_BACK:
			self.close()
					
	def onFocus(self,control):
		Log('onFocus: {}'.format(control))
		pass

	def setColor(self,color):
		self.setProperty('COLOR',color)
