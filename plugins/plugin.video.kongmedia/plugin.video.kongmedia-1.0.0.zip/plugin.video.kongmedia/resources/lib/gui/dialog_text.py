# -*- coding: utf-8 -*-

import xbmcgui

from resources.lib.modules._addon import *
from resources.lib.modules._common import *
from resources.lib.modules import panelcalls


class Account_Info(xbmcgui.WindowXMLDialog):

	HEADING_CTRL = 200
	TEXT_CTRL   = 201

	def __new__(cls,service_name):
		return super(Account_Info, cls).__new__(cls, 'Text_Box.xml', addon_path)

	def __init__(self,service_name,*args,**kwargs):
		super(Account_Info,self).__init__()
		self.service_name = service_name
		self.AccountInfo(self.service_name)
		self.setColor(self.service_name)
		self.setHeading(self.header)
		self.setText(self.text)

	def AccountInfo(self,service_name):
		epg_data = panelcalls.GetEpg(self.service_name)
		userinfo = epg_data.get('user_info')
		self.username = userinfo.get('username')
		self.maxcon   = userinfo.get('max_connections')
		self.status   = userinfo.get('status')
		expdate  = userinfo.get('exp_date')
		if expdate:
			self.expdate = FromTimeStamp(float(expdate),fmt='%H:%M %d.%m.%Y') 
		else:
			self.expdate = 'Never'
		self.trial    = 'No' if userinfo.get('is_trial') == '0' else 'Yes'
		self.text = 'Username: {}\n\nStatus: {}\n\nExpiry  Date: {}\n\nMax Connections: {}\n\nTrial: {}'.format(self.username,self.status,self.expdate,self.maxcon,self.trial)
		self.header ='{} service user account details'.format(self.service_name).title()
		#d=Account_Info('Text_Box.xml',addon_path,header=header,text=text,service_name=service_name)
		#d.doModal()


	def setColor(self,color):
		self.setProperty('COLOR',color)

	def setHeading(self, header):
		self.setProperty('HEADER',self.header)

	def setText(self,text):
		self.setProperty('TEXT',self.text)