# -*- coding: utf-8 -*-

import xbmcgui

from resources.lib.modules._addon import *
from resources.lib.modules._common import *



class Menu_Live(xbmcgui.WindowXML):

	ACTION_SELECT_ITEM       = 7
	ACTION_NAV_BACK          = 92
	ACTION_MOUSE_LEFT_CLICK  = 100
	ACTION_MOUSE_RIGHT_CLICK = 101
	ACTION_MOUSE_LONG_CLICK  = 108
	ACTION_CONTEXT_MENU      = 117

	MYACCOUNT               = 101
	SETTING                 = 102
	SELECTSERVICE           = 103
	BACK                    = 104
	QUICKLINKS              = 106

	def __new__(cls,item_list,service_name,*args,**kwargs):
		return super(Menu_Live, cls).__new__(cls, 'Live_Menu.xml', addon_path)

	def __init__(self,item_list,service_name,*args,**kwargs):
		super(Menu_Live,self).__init__()
		self.SERVICENAME = service_name
		self.LISTITEM = item_list
		self.TITLE = kwargs.get('title')
		self.URL = kwargs.get('url')
		self.setColor(self.SERVICENAME)

	def onInit(self):
		self.control_list = self.getControl(201)
		if not self.control_list.size() > 0: 
			for item in self.LISTITEM:
				label         = item[0]
				url           = item[1]
				description   = item[2]
				icon = eval('{}_icon'.format(self.SERVICENAME))
				url=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode=13"
				ItemList = xbmcgui.ListItem(label,path=url,thumbnailImage=icon)
				ItemList.setInfo('video',{ 'plot':description})
				ItemList.setProperty('IsPlayable','true')
				ItemList.setProperty('IsFolder','false')
				self.control_list.addItem(ItemList)
		self.setFocusId(201)

	def onFocus(self, control):
		Log('onFocus: {}'.format(control))
		pass

	def onAction(self,action):
		Log('Action: %s' % (action.getId()))
		if action == self.ACTION_SELECT_ITEM or action == self.ACTION_MOUSE_LEFT_CLICK:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus %s Pos %s'%(ActionID,PosID))
			if ActionID == 201:
				PosID = self.control_list.getSelectedPosition()
				label = self.LISTITEM[PosID][0]
				url = self.LISTITEM[PosID][1]
				RunModule(url=url,mode=13,name=label)
		elif action == self.ACTION_NAV_BACK:
			self.close()
		elif action in [self.ACTION_MOUSE_RIGHT_CLICK,self.ACTION_MOUSE_LONG_CLICK,self.ACTION_CONTEXT_MENU]:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus %s Pos %s'%(ActionID,PosID))
			if ActionID == 201:
				PosID = self.control_list.getSelectedPosition()
				label = self.LISTITEM[PosID][0]
				url = self.LISTITEM[PosID][1]
				mode = 13
				icon = eval('{}_icon'.format(self.SERVICENAME))
				u=CreateModule(url=url,mode=mode,name=label,description=self.SERVICENAME)
				item_list = [('[I]Add to Favourites[/I]',u,0),('[I]Add to QuickLink[/I]',u,1)]
				if HasAddon('plugin.program.super.favourites'):
					item_list.append(('[I]Add to Super Favourites[/I]',u,3))
				if mode==13:
					item_list.append(('[I]Play[/I]',u,2))
				from resources.lib.gui import context_menu
				d=context_menu.ContextMenu('Context_Menu.xml',addon_path,service=self.SERVICENAME,item_list=item_list)
				d.doModal()
				del d 

	def onClick(self, control):
		Log('onClick: {}'.format(control))
		if control == self.MYACCOUNT:
			from resources.lib.gui import dialog_text
			d=dialog_text.Account_Info(self.SERVICENAME)
			d.doModal()
			del d 
		elif control == self.SETTING:
			OpenSettings()
		elif control == self.SELECTSERVICE:
			from resources.lib.gui import select_service
			d=select_service.Select_Service()
			d.doModal()
			del d
		elif control == self.BACK:
			self.Close()
		elif control == self.QUICKLINKS:
			from resources.lib.gui import quicklinks
			d=quicklinks.QuickLinks(self.SERVICENAME)
			d.doModal()
			del d

	def setColor(self,color):
		self.setProperty('COLOR',color)

	def Close(self):
		Log('closing menu live list')
		self.close()