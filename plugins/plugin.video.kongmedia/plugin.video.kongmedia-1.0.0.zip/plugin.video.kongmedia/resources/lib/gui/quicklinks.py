# -*- coding: utf-8 -*-
import xbmcgui
from resources.lib.modules._addon import *
from resources.lib.modules._common import *

class QuickLinks(xbmcgui.WindowXML):

	ACTION_SELECT_ITEM       = 7
	ACTION_NAV_BACK          = 92
	ACTION_MOUSE_LEFT_CLICK  = 100
	ACTION_MOUSE_RIGHT_CLICK = 101
	ACTION_MOUSE_LONG_CLICK  = 108
	ACTION_CONTEXT_MENU      = 117

	SETTING                 = 102
	BACK                    = 104

	def __new__(cls,service_name):
		return super(QuickLinks, cls).__new__(cls, 'Quicklink_Dir.xml', addon_path)

	def __init__(self,service_name):
		Log('opening quicklinks window')
		super(QuickLinks,self).__init__()
		self.db          = DATABASE
		self.dbtable     = 'quicklinks'
		self.data        = dbReadAll(self.db,self.dbtable)
		self.COLOR       = RemoveFormatting(setting('qlframecolor'))
		self.SERVICENAME = service_name

	def onInit(self):
		self.setProperty('QLCOLOR',self.COLOR)
		self.control_list = self.getControl(201)
		if not self.control_list.size() > 0:
			for item in self.data:
				label  = item[0]
				url    = item[1]
				mode   = item[2]
				icon   = item[3]
				url=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
				ItemList = xbmcgui.ListItem(label,path=url,thumbnailImage=icon)
				self.control_list.addItem(ItemList)
		self.setFocusId(201)

	def onAction(self,action):
		Log('Action: {}'.format(action.getId()))
		if action == self.ACTION_SELECT_ITEM or action == self.ACTION_MOUSE_LEFT_CLICK:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus %s Pos %s'%(ActionID,PosID))
			if ActionID == 201:
				PosID = self.control_list.getSelectedPosition()
				label = self.data[PosID][0]
				url = self.data[PosID][1]
				mode = self.data[PosID][2]
				icon = self.data[PosID][3]
				if self.SERVICENAME == None:
					pattern = re.compile(r'\((.+?)\)',re.I)
					match = re.search(pattern,label.lower())
					if match:
						self.SERVICENAME = match.group(1)
				RunModule(url=url,mode=mode,name=label,description=self.SERVICENAME)
		elif action == self.ACTION_NAV_BACK:
			self.Close()
		elif action in [self.ACTION_MOUSE_RIGHT_CLICK,self.ACTION_MOUSE_LONG_CLICK,self.ACTION_CONTEXT_MENU]:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			Log('Action Focus {} Pos {}'.format(ActionID,PosID))
			if ActionID == 201:
				PosID = self.control_list.getSelectedPosition()
				label = self.data[PosID][0]
				url = self.data[PosID][1]
				mode = self.data[PosID][2]
				icon = self.data[PosID][3]
				u=CreateModule(url=url,mode=mode,name=label,description=self.SERVICENAME)
				item_list = [('[I]Remove[/I]',u,4),('[I]Rename[/I]',u,5)]
				if mode == 13:
					item_list.append(('[I]Play[/I]',u,2))
				from resources.lib.gui import context_menu
				d=context_menu.ContextMenu('Context_Menu.xml',addon_path,item_list=item_list,caller='quicklinks')
				d.doModal()
				if d.ReloadList:
					if d.ListRemove:
						self.RemoveList(PosID)
					elif d.ListUpdate:
						self.UpdateList()
				del d 

	def onClick(self, control):
		Log('onClick: {}'.format(control))
		if control == self.SETTING:
			OpenSettings()
		elif control == self.BACK:
			self.Close()

	def RemoveList(self,itemPosition):
		self.control_list = self.getControl(201)
		self.control_list.removeItem(itemPosition)

	def UpdateList(self):
		self.control_list = self.getControl(201)
		self.control_list.reset()
		self.data = dbReadAll(self.db,self.dbtable)
		for item in self.data:
			label  = item[0]
			url    = item[1]
			mode   = item[2]
			icon   = item[3]
			url=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)
			ItemList = xbmcgui.ListItem(label,path=url,thumbnailImage=icon)
			self.control_list.addItem(ItemList)
		self.setFocusId(201) 



	def Close(self,msg='Closing Quicklinks'):
		Log(msg)
		super(QuickLinks,self).close()

