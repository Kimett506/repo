import cgi
import os
import urllib
import xbmcaddon
import xbmcgui
import xbmcvfs
import xml.etree.ElementTree as ET
from resources.lib.modules._addon import *
from resources.lib.modules._common import *



class ContextMenu(xbmcgui.WindowXMLDialog):

	ACTION_SELECT_ITEM       = 7
	ACTION_PREVIOUS_MENU     = 10
	ACTION_NAV_BACK          = 92
	ACTION_MOUSE_LEFT_CLICK  = 100

	CLOSE_BUTTON = 4000

	KEY_ESC      = 61467
	KEY_NAV_BACK = 92

	def __new__(cls,*args,**kwargs):
		return super(ContextMenu, cls).__new__(cls, 'Context_Menu.xml', addon_path)

	def __init__(self,*args,**kwargs):
		super(ContextMenu,self).__init__()
		self.CALLER   = kwargs.get('caller')
		if self.CALLER == 'quicklinks':
			self.COLOR = RemoveFormatting(setting('qlframecolor'))
		else:
			self.COLOR = kwargs.get('service','blue')
		self.LISTITEM = kwargs.get('item_list')
		self.CALLER   = kwargs.get('caller')
		self.setProperty('COLOR',self.COLOR)
		self.SFPROFILE = TranslatePath('plugin.program.super.favourites','profile')
		self.SFFOLDER  = os.path.join(self.SFPROFILE, 'Super Favourites')
		self.SFKONGMEDIA = os.path.join(self.SFFOLDER,'kongmedia')
		self.SFKMXML = os.path.join(self.SFKONGMEDIA,'favourites.xml')
		self.ReloadList = False
		self.ListRemove = False
		self.ListUpdate = False

	def Close(self,msg='closing context menu'):
		Log(msg)
		self.close()

	def onInit(self):
		self.control_list = self.getControl(5000)
		if not self.control_list.size() > 0:
			for item in self.LISTITEM:
				label = item[0]
				path   = item[1]
				ItemList = xbmcgui.ListItem(label,path=path)
				self.control_list.addItem(ItemList)
		self.setFocusId(5000)

	def onAction(self,action):
		Log('Action: {}'.format(action.getId()))
		if action.getId() in [self.ACTION_NAV_BACK,self.KEY_NAV_BACK,self.ACTION_PREVIOUS_MENU]:
			self.Close('ContextMenu closed via action {}'.format(action.getId()))
		elif action.getId() in [self.ACTION_SELECT_ITEM,self.ACTION_MOUSE_LEFT_CLICK]:
			ActionID = self.getFocusId()
			PosID = self.control_list.getSelectedPosition()
			if ActionID == 5000:
				PosID = self.control_list.getSelectedPosition()
				label = self.LISTITEM[PosID][0]
				path = self.LISTITEM[PosID][1]
				mode = self.LISTITEM[PosID][2]
				if mode==0:
					self.AddFavXml(path)
				elif mode==1:
					self.AddQuickMenu(path)
				elif mode==2:				
					self.StreamPlay(path)
				elif mode==3:
					self.AddSupFav(path)
				elif mode==4:
					self.RemoveQuickLink(path)
				elif mode==5:
					self.RenameQuickLink(path)
				else:
					self.Close()
		elif action.getId() == self.ACTION_PREVIOUS_MENU and action.getButtonCode() == self.KEY_ESC:
			self.Close('Closed via escape')

	def onClick(self, control):
		Log('onClick: {}'.format(control))
		if control in [self.CLOSE_BUTTON]:
			self.Close()

	def AddFavXml(self,path):
		Log('Adding {} to Favourites.xml'.format(path))
		icon = addon_icon
		fav_list = list()
		params = self.RegexParam(path)
		fav_name = self.GetParam(params,'name')
		fav_des  = self.GetParam(params,'description')
		fav_mode = int(self.GetParam(params,'mode'))
		if fav_des.lower() in ['gold','red','green']:
			fav_name = '({}) {}'.format(fav_des.capitalize(),fav_name)
			icon = eval('{}_icon'.format(fav_des))
		if fav_mode == 13:
			fav_path = 'PlayMedia("{}")'.format(self.GetParam(params,'url'))
		else:
			fav_path = 'RunPlugin("{}")'.format(path)
		Log(fav_path)
		if PathExists(FAVOURITES):
			f = FileWrapper(FAVOURITES)
			tree = ET.parse(f)
			root = tree.getroot()
			for FAV in root.findall('favourite'):
				fav_list.append(FAV.get('name'))
			if not fav_name in fav_list:
				favElem = ET.Element('favourite')
				root.append(favElem)
				favElem.set('name',fav_name)
				favElem.set('thumb','special://home/addons/plugin.video.kongmedia/icon.png')
				favElem.text = fav_path
				tree.write(FAVOURITES)
				Notify(message='Added to favourite')
			else:
				Notify(message='Favourite All ready inc')
		self.Close()


	def AddSupFav(self,path):
		icon = addon_icon
		Log('adding {} to Super Favourite '.format(path))
		sf_list=list()
		params = self.RegexParam(path)
		sf_name = self.GetParam(params,'name')
		sf_des  = self.GetParam(params,'description')
		sf_mode = int(self.GetParam(params,'mode'))
		if sf_des.lower() in ['gold','red','green']:
			sf_name = '({}) {}'.format(sf_des.capitalize(),sf_name)
			icon = eval('{}_icon'.format(sf_des))
		if sf_mode==13:
			sf_path='PlayMedia("{}?sf_options=winID%3D10025%26_options_sf")'.format(self.GetParam(params,'url'))
		else:
			sf_path = 'RunPlugin("{}")'.format(path)
		Log(sf_path)
		if PathExists(self.SFFOLDER):
			CreateDir(self.SFKONGMEDIA)
			if not PathExists(self.SFKMXML):
				with open(self.SFKMXML,'a') as f:
					f.write('<favourites>\n</favourites>')
					f.close()
			if PathExists(self.SFKMXML):
				f = FileWrapper(self.SFKMXML)
				tree = ET.parse(f)
				root = tree.getroot()
				for FAV in root.findall('favourite'):
					sf_list.append(FAV.get('name'))
				if not sf_name in sf_list:
					favElem = ET.Element('favourite')
					root.append(favElem)
					favElem.set('name',sf_name)
					favElem.set('thumb','special://home/addons/plugin.video.kongmedia/icon.png')
					favElem.text = sf_path
					tree.write(self.SFKMXML)
					Notify(message='Added to Super favourites')
				else:
					Notify(message='All ready in Super Favourites')
		self.Close()

	def AddQuickMenu(self,path):
		icon = addon_icon
		ql_list = list()
		params = self.RegexParam(path)
		ql_name = self.GetParam(params,'name')
		ql_des  = self.GetParam(params,'description')
		ql_url  = self.GetParam(params,'url')
		ql_mode = self.GetParam(params,'mode')
		if ql_des.lower() in ['gold','red','green']:
			ql_name = '({}) {}'.format(ql_des.capitalize(),ql_name)
			icon = eval('{}_icon'.format(ql_des))
		ql_path = 'RunPlugin({})'.format(path)
		dbCreateTableHeaders(DATABASE,'quicklinks','name,url,mode,icon,path,service')
		if not dbIsInTable(DATABASE,'quicklinks','name',ql_name):
			dbWrite(DATABASE,'quicklinks',(ql_name,ql_url,ql_mode,icon,ql_path,ql_des))
			if dbIsInTable(DATABASE,'quicklinks','name',ql_name):
				Notify(message='Added to Quicklinks')
		else:
			Notify(message='Already in QuickLinks')
		self.Close()

	def RenameQuickLink(self,path):
		icon = addon_icon
		params  = self.RegexParam(path)
		ql_name = self.GetParam(params,'name')
		ql_des  = self.GetParam(params,'description')
		ql_url  = self.GetParam(params,'url')
		ql_mode = self.GetParam(params,'mode')
		if ql_des.lower() in ['gold','red','green']:
			icon = eval('{}_icon'.format(ql_des))
		if dbIsInTable(DATABASE,'quicklinks','name',ql_name):
			dbDeleteFrom(DATABASE,'quicklinks','name',ql_name)
		new_name = KeyBoard(msg='Enter new name for QuickLink',default=ql_name)
		ql_path = 'RunPlugin({})'.format(path)
		dbWrite(DATABASE,'quicklinks',(new_name,ql_url,ql_mode,icon,ql_path,ql_des))
		self.ReloadList = True
		self.ListUpdate = True
		self.Close('Quicklink renamed')

	def RemoveQuickLink(self,path):
		params = self.RegexParam(path)
		ql_name = self.GetParam(params,'name')
		if dbIsInTable(DATABASE,'quicklinks','name',ql_name):
			dbDeleteFrom(DATABASE,'quicklinks','name',ql_name)
			if not dbIsInTable(DATABASE,'quicklinks','name',ql_name):
				Notify(message='{} Has been removed from Quicklinks'.format(ql_name))
				self.ReloadList = True
				self.ListRemove = True
				self.Close('{} Has been removed from Quicklinks'.format(ql_name))
			else:
				Notify(message='Unable to remove {} from Quicklinks'.format(ql_name))
				self.Close('Unable to remove {} from Quicklinks'.format(ql_name))
		else:
			self.Close('Unable to remove quicklinks {}'.format(ql_name))

	def GetParam(self,params,paramName):
		#try:
		param=params[paramName]
		if param.isdigit():
			param = int(param)
		else:
			param=urllib.unquote_plus(param)
		#except:
			#param=None
		return param

	def RegexParam(self,path):
		param=[]
		params=path
		cleanedparams=params.replace('?','').replace('plugin://plugin.video.kongmedia/','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
		return param

	def StreamPlay(self,path):
		p = self.RegexParam(path)
		label=self.GetParam(p,'name')
		url=self.GetParam(p,'url')
		player = Xbmc_Player()
		listitem = xbmcgui.ListItem(label)
		player.play(url,listitem)
		self.Close()
		while(not xbmc.abortRequested):
			xbmc.sleep(100)

class Xbmc_Player(xbmc.Player):

	def __init__( self):
		self.is_active = True
		self.is_stopped = False
		self.urlplayed = False
		
	def onPlayBackStarted( self ):
		Log("#Playback Started#")
		self.urlplayed = True
		self.is_stopped = False
			
	def onPlayBackEnded( self ):
		Log('PlayBack Ended')
		self.is_active = False
		self.is_stopped = True
		
	def onPlayBackStopped( self ):
		Log('Playback Stopped')
		self.is_active = False
		self.is_stopped = True


class FileWrapper(object):
	def __init__(self, filename):
		self.vfsfile = xbmcvfs.File(filename,"rb")
		self.size = self.vfsfile.size()
		self.bytesRead = 0

	def close(self):
		self.vfsfile.close()

	def read(self, byteCount):
		self.bytesRead += byteCount
		return self.vfsfile.read(byteCount)

	def tell(self):
		return self.bytesRead
