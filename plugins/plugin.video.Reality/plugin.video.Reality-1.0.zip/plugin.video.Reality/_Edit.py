import xbmcaddon
import base64
MainBase = base64.b64decode ('aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3LzNxRGdXTlJC')
addon = xbmcaddon.Addon('plugin.video.Reality')